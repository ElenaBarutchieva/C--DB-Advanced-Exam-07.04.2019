﻿namespace Cinema.DataProcessor
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.Globalization;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Xml.Serialization;
    using Cinema.Data.Models;
    using Cinema.DataProcessor.ImportDto;
    using Data;
    using Newtonsoft.Json;

    public class Deserializer
    {
        private const string ErrorMessage = "Invalid data!";
        private const string SuccessfulImportMovie
            = "Successfully imported {0} with genre {1} and rating {2}!";
        private const string SuccessfulImportHallSeat
            = "Successfully imported {0}({1}) with {2} seats!";
        private const string SuccessfulImportProjection
            = "Successfully imported projection {0} on {1}!";
        private const string SuccessfulImportCustomerTicket
            = "Successfully imported customer {0} {1} with bought tickets: {2}!";

        public static string ImportMovies(CinemaContext context, string jsonString)
        {
            var sb = new StringBuilder();

            var deserialedMovies = JsonConvert.DeserializeObject<MovieDTO[]>(jsonString);

            var movies = new List<Movie>();

            foreach (var movieDTO in deserialedMovies)
            {
                if (!IsValid(movieDTO))
                {
                    sb.AppendLine(ErrorMessage);
                    continue;
                }

                var currentMovie = movies.FirstOrDefault(m => m.Title == movieDTO.Title);

                if (currentMovie == null)
                {
                    currentMovie = new Movie
                    {
                        Title = movieDTO.Title,
                        Genre = movieDTO.Genre,
                        Duration = movieDTO.Duration,
                        Rating = movieDTO.Rating,
                        Director = movieDTO.Director
                    };
                }

                movies.Add(currentMovie);
                sb.AppendLine($"Successfully imported {currentMovie.Title} with genre {currentMovie.Genre} and rating {currentMovie.Rating:f2}!");
            }

            context.Movies.AddRange(movies);
            context.SaveChanges();

            return sb.ToString().TrimEnd();
        }

        public static string ImportHallSeats(CinemaContext context, string jsonString)
        {
            var sb = new StringBuilder();

            var deserialedHalls = JsonConvert.DeserializeObject<HallDTO[]>(jsonString);

            var halls = new List<Hall>();
            var seats = new List<Seat>();

            foreach (var hallDTO in deserialedHalls)
            {
                if (!IsValid(hallDTO))
                {
                    sb.AppendLine(ErrorMessage);
                    continue;
                }

                var hall = halls.FirstOrDefault(h => h.Name == hallDTO.Name);

                if (hall == null)
                {
                    hall = new Hall
                    {
                        Name = hallDTO.Name,
                        Is4Dx = hallDTO.Is4Dx,
                        Is3D = hallDTO.Is3D
                    };
                }

                var currentSeats = new List<Seat>();

                if (hallDTO.Seats <= 0)
                {
                    sb.AppendLine(ErrorMessage);
                    continue;
                }
                else
                {
                    for (int i = 1; i <= hallDTO.Seats; i++)
                    {
                        var currentSeat = new Seat
                        {
                            HallId = hall.Id
                        };
                        currentSeats.Add(currentSeat);
                    }
                }

                hall.Seats = currentSeats;
                halls.Add(hall);
                if (hall.Is3D && !hall.Is4Dx)
                {
                    sb.AppendLine($"Successfully imported {hall.Name}(3D) with {hall.Seats.Count} seats!");
                }
                if (hall.Is4Dx && !hall.Is3D)
                {
                    sb.AppendLine($"Successfully imported {hall.Name}(4Dx) with {hall.Seats.Count} seats!");
                }
                if (hall.Is3D && hall.Is4Dx)
                {
                    sb.AppendLine($"Successfully imported {hall.Name}(4Dx/3D) with {hall.Seats.Count} seats!");
                }
                if (!hall.Is4Dx && !hall.Is3D)
                {
                    sb.AppendLine($"Successfully imported {hall.Name}(Normal) with {hall.Seats.Count} seats!");
                }
            }

            context.Halls.AddRange(halls);
            context.SaveChanges();

            return sb.ToString().TrimEnd();
        }

        public static string ImportProjections(CinemaContext context, string xmlString)
        {
            var sb = new StringBuilder();

            var serializer = new XmlSerializer(typeof(ProjectionDTO[]), new XmlRootAttribute("Projections"));

            var deserialized = (ProjectionDTO[])serializer.Deserialize(new StringReader(xmlString));

            var projections = new List<Projection>();

            foreach (var projectionDTO in deserialized)
            {
                if (!IsValid(projectionDTO)
                    || context.Halls.FirstOrDefault(h => h.Id == projectionDTO.HallId) == null
                    || context.Movies.FirstOrDefault(h => h.Id == projectionDTO.MovieId) == null )
                {
                    sb.AppendLine(ErrorMessage);
                    continue;
                }

                var projection = context.Projections.SingleOrDefault(p => p.MovieId == projectionDTO.MovieId);
                
                var date = DateTime.ParseExact(projectionDTO.DateTime, "yyyy-MM-dd HH:mm:ss", CultureInfo.InvariantCulture);

                if (projection == null)
                {
                    projection = new Projection
                    {
                        MovieId = projectionDTO.MovieId,
                        HallId = projectionDTO.HallId,
                        DateTime = date
                    };
                }
                string movieName = context.Movies.First(m => m.Id == projectionDTO.MovieId).Title;
                projections.Add(projection);
                sb.AppendLine($"Successfully imported projection {movieName} on {projection.DateTime.ToString("MM/dd/yyyy")}!");
            }

            context.Projections.AddRange(projections);
            context.SaveChanges();
            return sb.ToString().TrimEnd();
        }

        public static string ImportCustomerTickets(CinemaContext context, string xmlString)
        {
            var sb = new StringBuilder();

            var serializer = new XmlSerializer(typeof(CustomerDTO[]), new XmlRootAttribute("Customers"));

            var deserialized = (CustomerDTO[])serializer.Deserialize(new StringReader(xmlString));

            var customers = new List<Customer>();


            foreach (var customerDTO in deserialized)
            {
                if (!IsValid(customerDTO))
                {
                    sb.AppendLine(ErrorMessage);
                    continue;
                }

                var customer = context.Customers.SingleOrDefault(c => c.FirstName == customerDTO.FirstName);
                

                if (customer == null)
                {
                    customer = new Customer
                    {
                        FirstName = customerDTO.FirstName,
                        LastName = customerDTO.LastName,
                        Age = customerDTO.Age,
                        Balance = customerDTO.Balance
                    };
                }

                var tickets = new List<Ticket>();
                foreach (var ticketDTO in customerDTO.Tickets)
                {
                    if (!IsValid(ticketDTO))
                    {
                        sb.AppendLine(ErrorMessage);
                        continue;
                    }

                    //var ticket = context.Tickets.Single(t => t.Price == ticketDTO.Price);

                    var ticket = new Ticket
                    {
                        Price = ticketDTO.Price,
                        ProjectionId = ticketDTO.ProjectionId
                    };

                    tickets.Add(ticket);
                }

                customer.Tickets = tickets;
                customers.Add(customer);
                sb.AppendLine($"Successfully imported customer {customer.FirstName} {customer.LastName} with bought tickets: {tickets.Count}!");
            }

            context.Customers.AddRange(customers);
            context.SaveChanges();
            return sb.ToString().TrimEnd();
        }

        private static bool IsValid(object obj)
        {
            var validationContext = new ValidationContext(obj);
            var validationResults = new List<ValidationResult>();

            var isValid = Validator.TryValidateObject(obj, validationContext, validationResults, true);

            return isValid;
        }
    }
}