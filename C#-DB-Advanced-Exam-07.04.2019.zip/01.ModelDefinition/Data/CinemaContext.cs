﻿namespace Cinema.Data
{
    using Cinema.Data.Models;
    using Microsoft.EntityFrameworkCore;

    public class CinemaContext : DbContext
    {
        public CinemaContext()  { }

        public CinemaContext(DbContextOptions options)
            : base(options)   { }

        public DbSet<Movie> Movies { get; set; }
        public DbSet<Hall> Halls { get; set; }
        public DbSet<Customer> Customers { get; set; }
        public DbSet<Ticket> Tickets { get; set; }
        public DbSet<Seat> Seats { get; set; }
        public DbSet<Projection> Projections { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
                optionsBuilder
                    .UseSqlServer(Configuration.ConnectionString);
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder
                .Entity<Movie>()
                .HasMany(m => m.Projections)
                .WithOne(p => p.Movie);

            modelBuilder
                .Entity<Hall>()
                .HasMany(h => h.Projections)
                .WithOne(p => p.Hall);

            modelBuilder
                .Entity<Hall>()
                .HasMany(h => h.Seats)
                .WithOne(s => s.Hall);

            modelBuilder
                .Entity<Projection>()
                .HasMany(p => p.Tickets)
                .WithOne(t => t.Projection);

            modelBuilder
                .Entity<Customer>()
                .HasMany(c => c.Tickets)
                .WithOne(t => t.Customer);
        }
    }
}